﻿using FluentAssertions;
using System;
using System.Collections.Generic;
using System.Linq;
using Utils;
using Xunit;

namespace $rootnamespace$
{
    public class $basename$
    {
        [Theory]
        [InlineData("Data/$basename$_Test.txt", 0)]
        [InlineData("Data/$basename$.txt", 0)]
        public void Part1(string filename, long expectedAnswer)
        {

        }

        [Theory]
        [InlineData("Data/$basename$_Test.txt", 0)]
        [InlineData("Data/$basename$.txt", 0)]
        public void Part2(string filename, long expectedAnswer)
        {

        }
    }
}
